//This is a project to manage employees and managers.

#include <iostream>
#include <iomanip>
#include "Employee.h"
#include "Manager.h"
// Author: Jacob Henke
// BannerID: 001396101
// Course: CS 181
// Assignment: PA4
// Date Assigned: Monday, March 18, 2024
// Date/Time Due: Saturday, March 30, 2024 -- 11:55 pm
// Description: This program will exercise Object Oriented concepts with C++.
// Certification of Authenticity:
// I certify that this assignment is entirely my own work.

using namespace std;
int main() {
    int num;
    double wage,hours,bonus;
    string name,strnum;
    cout << "Enter number of managers:\n";
    getline(cin,strnum);
    num = stoi(strnum);
    Manager *managers[num];

    // get input from user
    for (int i=0;i<num;i++) {
        cout << "Enter manager " << i << " name:\n";
        getline(cin,name);
        cout << "Enter manager " << i << " hourly wage:\n";
        cin >> wage;
        cout << "Enter manager " << i << " hours worked:\n";
        cin >> hours;
        cout << "Enter manager " << i << " bonus:\n";
        cin >> bonus;
        Manager* tmp = new Manager;
        tmp->setName(name);
        tmp->setWage(wage);
        tmp->setHours(hours);
        tmp->setBonus(bonus);
        managers[i] = tmp;
        cin.get();
    }

    // iterate over managers to find highest paid and average pay
    int highestNum=-1;
    double highest=-1;
    double total=0;
    for (int i=0;i<num;i++) {
        if (managers[i]->calcPay() > highest) {
            highestNum = i;
            highest = managers[i]->calcPay();
        }
        total+=managers[i]->calcPay();
    }
    double avg = total/static_cast<double>(num);
    cout.precision(2);
    cout.setf(ios::fixed,ios::floatfield);
    cout << "Highest paid manager is " << managers[highestNum]->getName() << " who is paid $" << highest << endl;
    cout << "Average pay is $" << avg;
}

#include "Manager.h"

double Manager::calcPay() const
{
    return (wage * hours) + bonus;
}
//Manager::Manager() {}
//Manager::Manager(string name, double wage, double hours, double bonus)
//{
    //ctor
//}

void Manager::setName(string n) {
    name = n;
}
void Manager::setWage(double w) {
    wage = w;
}
void Manager::setHours(double h) {
    hours = h;
}
void Manager::setBonus(double b) {
    bonus = b;
}

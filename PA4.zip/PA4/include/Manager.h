#ifndef MANAGER_H
#define MANAGER_H

#include <Employee.h>


class Manager : public Employee
{
    private:
        double bonus;
    public:
        //Manager();
        //Manager(string, double, double, double);
        double calcPay() const;
        void setName(string);
        void setWage(double);
        void setHours(double);
        void setBonus(double);
};

#endif // MANAGER_H
